from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('',views.index,name="index"),
    path('about/',views.about,name="about"),
    path('product/<int:product_id>/', views.product, name='product'),
    path('login_user/',views.login_user,name="login"),
    path('logout_user/',views.logout_user,name="logout"),
    path('register/',views.register_user,name="register"),
    path('search/',views.search,name="search"),
]


