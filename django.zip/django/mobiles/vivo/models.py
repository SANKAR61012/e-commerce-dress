from django.db import models

# Create your models here.
import datetime
from django.contrib.auth.models import User
from django.db.models.signals import post_save #will automatically allows use another profile

class Category(models.Model):
    name = models.CharField(max_length=50)
    
    def __str__(self): #tells dj
        return self.name
    
    #class Meta:
       # verbose_name_plural = "categories"

class Product(models.Model):
    name= models.CharField(max_length=100)
    price=models.DecimalField(default=0, decimal_places=2 , max_digits=6)
    category=models.ForeignKey(Category, on_delete=models.CASCADE, default=1)
    description=models.CharField(max_length=250, default='', blank=True , null=True)
    imaage=models.ImageField(upload_to='uploads/product/')
    #add sale stuff
    is_sale = models.BooleanField(default=False) #not on sale
    sale_price = models.DecimalField(default=0, decimal_places=2, max_digits=6)
    def __str__(self):
        return self.name
    
    