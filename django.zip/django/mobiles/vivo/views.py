from django.shortcuts import render,redirect,get_object_or_404
from .models import Product, Category
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from .forms import SignUpForm
from django.db.models import Q
from django.contrib.auth.forms import User

# Create your views here.....::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

def index(request):
    products= Product.objects.all()
    return render(request,"index.html",{'products':products})

def about(request):
    return render(request,"about.html") 

def product(request,product_id):
    product = get_object_or_404(Product, id=product_id)
    return render(request,"product.html",{'product':product}) 
#-----------------------------------------------------------------------------------------------#
def login_user(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request,user)
            messages.success(request,("you have been logged in!"))
            return redirect('index')
        else:
            messages.success(request,("There was an error, please try again..."))
            return redirect('login')
    else:
        return render(request, 'loginpage.html',{})

def logout_user(request):
    if request.user.is_authenticated:
        logout(request)
        messages.success(request,("You have been logged out... Thanks for stoppping by..."))
        return redirect('index')
    else:
        messages.error(request,"please try again...!")

def register_user(request):
    form = SignUpForm(request.POST or None)
    if request.method == 'POST':
        if form.is_valid():
            form.save()
            messages.success(request, 'Registration successful! You can log in now...')
            return redirect('login')
        else:
            messages.error(request, 'Please try again...!')
    return render(request, 'register.html',{'form':form})

# def search(request):
#     if request.method == "POST":
#         serached = request.POST.get('serached')
#         serached = Product.objects.filter(Q(name_icontains = serached) | Q(description_icontains=serached))
#         if not serached:
#             messages.success(request,"that product Does not Exist...Please try again...!")
#             return render(request,"search.html",{})
#         else:
#             return render(request,"search.html",{'searched':serached})
#     else:
#         return render(request,"search.html",{})
    
def search(request):

    # Determine if they filled out the form

    if request.method == "POST":

        searched = request.POST['searched'] #to get the searched name in html.

        # Query The Products DB Model

        searched = Product.objects.filter(Q(name__icontains=searched) | Q(description__icontains=searched))

        # Test for null

        if not searched:

            messages.success(request, "That Product Does Not Exist...Please try Again.")

            return render(request, "search.html", {})

        else:

            return render(request, "search.html", {'searched':searched})

    else:

        return render(request, "search.html", {})